#!/usr/bin/env python3
"""unit_to_slides.py

Create a first-draft Quarto reveal.js slide deck from a unit .qmd.

Usage:
  python scripts/unit_to_slides.py path/to/unit.qmd slides/unit-slides.qmd

What it does:
- reads YAML title
- extracts unit blocks (overview/goals/reading/summary/resources/practice)
- creates one slide per '##' section in the Reading block
- generates compact bullets (first few sentences)
- includes the full original section text as speaker notes

This produces a good draft; tighten bullets for “high polish”.
"""

from __future__ import annotations
from pathlib import Path
import re
import sys

def extract_div(text: str, cls: str) -> str:
    pat = rf":::\s*\{{\s*\.{re.escape(cls)}\s*\}}\s*(.*?)\s*:::\s*<!-- end {re.escape(cls)} div -->"
    m = re.search(pat, text, flags=re.S)
    return m.group(1).strip() if m else ""

def parse_title(text: str) -> str:
    m = re.search(r"^---\s*\n(.*?)\n---\s*\n", text, flags=re.S|re.M)
    if not m:
        return "Slides"
    yaml = m.group(1)
    mt = re.search(r"^title:\s*(.*)\s*$", yaml, flags=re.M)
    return mt.group(1).strip().strip('"').strip("'") if mt else "Slides"

def clean_md(text: str) -> str:
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    return re.sub(r"\s+", " ", text).strip()

def split_sentences(text: str) -> list[str]:
    txt = clean_md(text)
    parts = re.split(r"(?<=[.!?])\s+", txt)
    return [p.strip() for p in parts if p.strip()]

def bullets_from(text: str, max_bullets: int = 4) -> list[str]:
    sents = split_sentences(text)
    out = []
    for s in sents[:max_bullets]:
        if len(s) > 160:
            s = s[:157].rstrip() + "…"
        out.append(s)
    return out

def parse_reading_subsections(reading_block: str) -> list[tuple[str, str]]:
    reading_wo = re.sub(r"^\s*#\s*Reading\s*", "", reading_block, flags=re.M).strip()
    chunks = re.split(r"\n##\s+", "\n" + reading_wo)
    subsections = []
    for chunk in chunks:
        chunk = chunk.strip()
        if not chunk:
            continue
        lines = chunk.splitlines()
        title = lines[0].strip()
        body = "\n".join(lines[1:]).strip()
        if title:
            subsections.append((title, body))
    return subsections

def extract_bullets(block: str) -> list[str]:
    out = []
    for line in block.splitlines():
        if re.match(r"^\s*[*-]\s+", line):
            out.append(re.sub(r"^\s*[*-]\s+", "", line).strip())
    return out

def main() -> int:
    if len(sys.argv) != 3:
        print("Usage: python scripts/unit_to_slides.py unit.qmd out-slides.qmd", file=sys.stderr)
        return 2

    unit_path = Path(sys.argv[1])
    out_path = Path(sys.argv[2])
    text = unit_path.read_text(encoding="utf-8")

    title = parse_title(text)
    overview = extract_div(text, "unit-overview")
    goals = extract_div(text, "unit-goals")
    reading = extract_div(text, "unit-reading")
    summary = extract_div(text, "unit-summary")
    resources = extract_div(text, "unit-resources")
    practice = extract_div(text, "unit-exercise")

    goal_bullets = extract_bullets(goals)
    practice_bullets = extract_bullets(practice)
    resource_bullets = extract_bullets(resources)

    subsections = parse_reading_subsections(reading)

    out = []
    out.append("---")
    out.append(f'title: "{title}"')
    out.append('subtitle: "Auto-generated slides (edit for polish)"')
    out.append('format:')
    out.append('  revealjs:')
    out.append('    theme: [default, theme.scss]')
    out.append('    slide-number: true')
    out.append('    progress: true')
    out.append('    hash: true')
    out.append('    center: false')
    out.append('    navigation-mode: linear')
    out.append('    transition: fade')
    out.append('    background-transition: fade')
    out.append('    menu: true')
    out.append(f'    footer: "{title}"')
    out.append('---\n')

    ov = clean_md(overview.replace('# Overview', '').strip())
    if ov:
        out.append('## Overview\n')
        out.append(ov + '\n')
        out.append('::: {.notes}')
        out.append(overview)
        out.append(':::\n')

    if goal_bullets:
        out.append('## Goals\n')
        for g in goal_bullets:
            out.append(f'* {g}')
        out.append('\n::: {.notes}')
        out.append(goals)
        out.append(':::\n')

    for sec_title, sec_body in subsections:
        out.append(f'## {sec_title}\n')
        for b in bullets_from(sec_body, max_bullets=4):
            out.append(f'* {b}')
        out.append('\n::: {.notes}')
        out.append(sec_body)
        out.append(':::\n')

    if summary:
        out.append('## Summary\n')
        for b in bullets_from(summary, max_bullets=4):
            out.append(f'* {b}')
        out.append('\n::: {.notes}')
        out.append(summary)
        out.append(':::\n')

    if practice_bullets:
        out.append('## Practice\n')
        for p in practice_bullets:
            out.append(f'* {p}')
        out.append('\n::: {.notes}')
        out.append(practice)
        out.append(':::\n')

    if resource_bullets:
        out.append('## Further resources\n')
        for r in resource_bullets:
            out.append(f'* {r}')
        out.append('\n::: {.notes}')
        out.append(resources)
        out.append(':::\n')

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text('\n'.join(out), encoding='utf-8')
    print(f'Wrote: {out_path}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
